#!/bin/bash
blue='\e[0;34'
cyan='\e[0;36m'
green='\e[0;34m'
okegreen='\033[92m'
lightgreen='\e[1;32m'
white='\e[1;37m'
red='\e[1;31m'
yellow='\e[1;33m'

#Membuat direktori
touch RzGrab.txt
clear
banner(){
echo -e $okegreen" __  __                ____           _     _"
echo -e $red"|  \/  | __ _ ___ ___ / ___|_ __ __ _| |__ | |__   ___ _ __"
echo -e $yellow"| |\/| |/ _- / __/ __| |  _| -__/ _- | -_ \| -_ \ / _ \ -__|"
echo -e $cyan"| |  | | (_| \__ \__ \ |_| | | | (_| | |_) | |_) |  __/ |"
echo -e $okegreen"|_|  |_|\__,_|___/___/\____|_|  \__,_|_.__/|_.__/ \___|_|
|-----------------------------------|
     [ R Z  -  G R A B  v 0 . 1 ]
|-----------------------------------|
         [ v0.1 / Beta  ]
"
#choose && Get domain From Curl 
echo -e $yellow  " ______________________"
read -p "  | [  Choose (1-100)  ] :  " domain
read -p "  | [ HALAMAN ] : " hal1;
read -p "  | [ SAMPAI HALAMAN ] : " hal2
}
banner
for((i=$hal1;i<=$hal2;i++))
do
curr=$(curl -s "https://net.all-url.info/$domain/$i/" | grep -oP '<a href=https://net.all-url.info/net/(.*?)>(.*?)</a>' | cut -d "<" -f2 | cut -d ">" -f2)
c=$(echo "$curr" | wc -l)
b=$(cat RzGrab.txt | wc -l 2>/dev/null)
if [[ $curr =~ '.net' ]]; then
echo "$curr" >> RzGrab.txt
echo -e $cyan"================================================================"
echo -e "${yellow}(✓)PAGES :$red $i|$domain $white| $cyan DOMAIN GRABBER $yellow=> $red $c $white | $lightgreen SAVED(✓) $yellow=> $lightgreen[ $c $lightgreen]"
else
echo -e "${red}[×] LIMIT RESULT"
	fi
done